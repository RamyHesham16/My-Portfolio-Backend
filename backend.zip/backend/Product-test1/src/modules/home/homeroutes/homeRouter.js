import { Router } from "express";
import {getHomeData,updateHomeData} from "../home.controllers/homeController.js"
const router = Router();

router.get('/',getHomeData) ;
router.patch('/',updateHomeData) ;

export default router;
