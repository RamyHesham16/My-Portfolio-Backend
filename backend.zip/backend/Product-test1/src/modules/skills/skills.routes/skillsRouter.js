import { Router } from "express";
import {
  getSkillsData,
  updateSkillsData,
  deleteSkillsData,
  addNewSkill,
} from "../skills.controllers/skillsController.js";
const router = Router();

router.get("/", getSkillsData);
router.post("/", addNewSkill);
router.patch("/:id", updateSkillsData);
router.delete("/:id", deleteSkillsData);

export default router;
