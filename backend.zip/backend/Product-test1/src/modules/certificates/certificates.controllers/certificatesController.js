import { Certificates } from "../../../../databases/dbConnection.js";

export async function getCertificatesData(req, res) {
  try {
    const CertificatesData = await Certificates.find();
    res.json(CertificatesData);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}
export async function updateCertificatesData(req, res) {
  try {
    const id = req.params.id;
    const updatedData = await Certificates.findByIdAndUpdate({ _id: id }, req.body, { new: true });
    res.json(updatedData);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}
export async function deleteCertificatesData(req, res) {
  try {
    const id = req.params.id;
    const updatedData = await Certificates.findByIdAndDelete({ _id: id }, { new: true });
    res.json({ message: "success" });
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}

export async function addCertificatesData(req, res) {
  try {
    const newCertificate = Certificates.create(req.body);
    res.json(newCertificate);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}
