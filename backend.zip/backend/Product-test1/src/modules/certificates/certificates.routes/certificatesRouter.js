import { Router } from "express";
import {
  getCertificatesData,
  updateCertificatesData,
  deleteCertificatesData,
  addCertificatesData,
} from "../certificates.controllers/certificatesController.js";
const router = Router();

router.get("/", getCertificatesData);
router.patch("/:id", updateCertificatesData);
router.post("/", addCertificatesData);
router.delete("/:id", deleteCertificatesData);

export default router;
