import { Router } from "express";
import {getResumeData,updateResumeData} from "../resume.controllers/resumeController.js";
const router = Router();

router.get('/',getResumeData);
router.patch('/',updateResumeData) ;

export default router;
