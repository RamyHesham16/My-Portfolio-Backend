import {Home} from "../../../../databases/dbConnection.js"; 

export async function getHomeData(req, res) {
    try {
        const homeData = await Home.find() ;
        res.json(homeData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


} ;

export async function updateHomeData(req, res) {
    try {
        
        const updatedData = await Home.findByIdAndUpdate({_id:"66c10500e21af47cb0f7bc32"},req.body,{new:true})
        res.json(updatedData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


}

