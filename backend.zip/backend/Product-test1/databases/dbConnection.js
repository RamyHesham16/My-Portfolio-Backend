import { connect, Schema, model } from 'mongoose';
connect('mongodb://127.0.0.1:27017/RH-portfolio')
export const homeSchema = new Schema({
name: String,
description1: String,
description2: String,
links:[String],
},{
timestamps: true,
})
export const aboutSchema = new Schema({
img: String,
description : String,

})
export const resumeSchema = new Schema({
img: String,
CVSourceUrl: String,

})
export const CertificatesSchema = new Schema({
img: String,
title: String,
description: String,
link : String,
})
export const skillsSchema = new Schema({
    category: String,
    img : String,
    name : String,
    imgUrl : String,
    })
    
// create a new model
export const Home = model('Home', homeSchema);
export const About = model('About', aboutSchema);
export const Resume = model('Resume', resumeSchema);
export const Certificates = model('Certificates', CertificatesSchema);
export const Skills = model('Skills', skillsSchema);