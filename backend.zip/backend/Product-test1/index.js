import express, { json } from "express";
import cors from "cors";
import multer from "multer";
const app = express();
const port = 3000;
// import routes
import homeRouter from "./src/modules/home/homeroutes/homeRouter.js";
import aboutRouter from "./src/modules/about/about.routes/aboutRouter.js";
import resumeRouter from "./src/modules/resume/resume.routes/resumeRouter.js";
import certificatesRouter from "./src/modules/certificates/certificates.routes/certificatesRouter.js";
import skillsRouter from "./src/modules/skills/skills.routes/skillsRouter.js";

// middlewares
app.use(json(), cors());
app.use("/uploads", express.static("uploads"));
app.use("/home", homeRouter);
app.use("/about", aboutRouter);
app.use("/resume", resumeRouter);
app.use("/certificates", certificatesRouter);
app.use("/skills", skillsRouter);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads");
  },
  filename: (req, file, cb) => {
    cb(null, `${file.originalname}`);
  },
});
const upload = multer({ storage: storage });

// Upload file route
app.post("/upload", upload.single("file"), (req, res) => {
  res.status(200).json({
    status: "success",
    message: "File uploaded successfully",
    filepath: `http://localhost:3000/uploads/${req.file.filename}`,
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
