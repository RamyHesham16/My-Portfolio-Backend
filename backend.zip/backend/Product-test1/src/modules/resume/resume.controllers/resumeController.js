import {Resume} from "../../../../databases/dbConnection.js"; 

export async function getResumeData(req, res) {
    try {
        const resumetData = await Resume.find() ;
        res.json(resumetData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


}
export async function updateResumeData(req, res) {
    try {
        
        const updatedData = await Resume.findByIdAndUpdate({_id:"66c19ce72c560f296efcab66"},req.body,{new:true})
        res.json(updatedData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


}
