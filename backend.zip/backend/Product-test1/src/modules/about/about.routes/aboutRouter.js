import { Router } from "express";
import {getAboutData,updateAboutData} from "../about.controllers/aboutController.js"
const router = Router();

router.get('/',getAboutData);
router.patch('/',updateAboutData) ;

export default router;
