import {About} from "../../../../databases/dbConnection.js"; 

export async function getAboutData(req, res) {
    try {
        const aboutData = await About.find() ;
        res.json(aboutData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


}

export async function updateAboutData(req, res) {
    try {
        
        const updatedData = await About.findByIdAndUpdate({_id:"66c199752c560f296efcab5b"},req.body,{new:true})
        res.json(updatedData)

    }catch(e) {
        res.status(500).send("Server Error");
        return;
    }


}

