import { Skills } from "../../../../databases/dbConnection.js";

export async function getSkillsData(req, res) {
  try {
    const skillsData = await Skills.find();
    res.json(skillsData);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}

export async function updateSkillsData(req, res) {
  try {
    const id = req.params.id;
    const updatedData = await Skills.findByIdAndUpdate({ _id: id }, req.body, { new: true });
    res.json(updatedData);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}

export async function deleteSkillsData(req, res) {
  try {
    const id = req.params.id;
    const updatedData = await Skills.findByIdAndDelete({ _id: id }, { new: true });
    res.json({ message: "success" });
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}

export async function addNewSkill(req, res) {
  try {
    const newSkill = Skills.create(req.body);
    res.json(newSkill);
  } catch (e) {
    res.status(500).send("Server Error");
    return;
  }
}
